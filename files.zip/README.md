# 🎓 EduFlow LMS — Full-Stack Learning Management System

A production-ready Learning Management System built with **FastAPI** (Python) + **React** (Vite), featuring role-based access control for students, instructors, and admins.

---

## 📁 Project Structure

```
lms/
├── backend/
│   ├── core/
│   │   ├── config.py        # Settings via pydantic-settings
│   │   ├── database.py      # SQLAlchemy engine + session
│   │   └── security.py      # JWT, hashing, role deps
│   ├── models/
│   │   ├── user.py          # User model (student/instructor/admin)
│   │   ├── course.py        # Course model
│   │   ├── lesson.py        # Lesson model
│   │   ├── enrollment.py    # Enrollment model
│   │   ├── quiz.py          # Quiz, Question, QuizAttempt models
│   │   └── progress.py      # Progress tracking model
│   ├── schemas/
│   │   ├── user.py          # User Pydantic schemas
│   │   ├── course.py        # Course Pydantic schemas
│   │   └── content.py       # Lesson, Quiz, Progress schemas
│   ├── routers/
│   │   ├── auth.py          # /api/v1/auth
│   │   ├── users.py         # /api/v1/users (admin)
│   │   ├── courses.py       # /api/v1/courses
│   │   ├── lessons.py       # /api/v1/courses/{id}/lessons
│   │   ├── enrollments.py   # /api/v1/enrollments
│   │   ├── quizzes.py       # /api/v1/courses/{id}/quizzes
│   │   └── progress.py      # /api/v1/progress
│   ├── main.py              # FastAPI app entry point
│   ├── schema.sql           # MySQL schema (reference)
│   ├── requirements.txt
│   └── .env.example
│
└── frontend/
    ├── src/
    │   ├── components/
    │   │   ├── common/      # ProtectedRoute, UI components
    │   │   └── layout/      # Sidebar, MainLayout, PageHeader
    │   ├── context/
    │   │   └── AuthContext.jsx
    │   ├── pages/
    │   │   ├── auth/        # LoginPage, RegisterPage
    │   │   ├── student/     # Dashboard, Browse, MyCourses, CourseDetail, QuizAttempt
    │   │   ├── instructor/  # Dashboard, CourseForm, CourseManage, QuizQuestions, Students
    │   │   └── admin/       # Dashboard, AdminUsers, AdminCourses
    │   ├── services/
    │   │   └── api.js       # Axios instance + all API functions
    │   ├── App.jsx
    │   └── main.jsx
    ├── index.html
    ├── package.json
    └── vite.config.js
```

---

## 🚀 Local Setup Instructions

### Prerequisites
- Python 3.11+
- Node.js 18+
- MySQL 8.0+

---

### 1. Database Setup

```bash
# Log into MySQL
mysql -u root -p

# Create database
CREATE DATABASE lms_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
EXIT;
```

---

### 2. Backend Setup

```bash
cd lms/backend

# Create and activate virtual environment
python -m venv venv
source venv/bin/activate     # Linux/macOS
# venv\Scripts\activate      # Windows

# Install dependencies
pip install -r requirements.txt

# Create .env file from example
cp .env.example .env

# Edit .env with your database credentials
nano .env   # or use any editor
```

**Edit `.env`:**
```env
DATABASE_URL=mysql+pymysql://root:YOUR_PASSWORD@localhost:3306/lms_db
SECRET_KEY=your-super-secret-key-at-least-32-characters-long
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=60
ALLOWED_ORIGINS=http://localhost:5173
```

```bash
# Start the backend server (auto-creates DB tables on first run)
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

API is now running at: **http://localhost:8000**  
Swagger docs: **http://localhost:8000/docs**

---

### 3. Frontend Setup

```bash
cd lms/frontend

# Install dependencies
npm install

# Start dev server
npm run dev
```

Frontend is now running at: **http://localhost:5173**

---

## 🔐 How to Use

### First Time Setup
1. Go to **http://localhost:5173/register**
2. Register an **admin** account first
3. Register an **instructor** account
4. Register one or more **student** accounts

### Typical Workflow
1. **Instructor** creates a course, adds lessons and quizzes with questions
2. Instructor publishes the course (`is_published = true`)
3. **Student** browses courses, enrolls in one
4. Student watches lessons and marks them complete
5. Student attempts a quiz and sees results
6. **Admin** monitors users and courses from the admin panel

---

## 📡 API Endpoints Summary

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/v1/auth/register` | Register new user |
| POST | `/api/v1/auth/login` | Login, get JWT |
| GET | `/api/v1/auth/me` | Get current user |
| GET | `/api/v1/courses` | List all published courses |
| POST | `/api/v1/courses` | Create course (instructor) |
| GET | `/api/v1/courses/{id}/lessons` | List lessons (enrolled students) |
| POST | `/api/v1/enrollments/{course_id}` | Enroll in course |
| GET | `/api/v1/enrollments/my` | My enrolled courses + progress |
| GET | `/api/v1/courses/{id}/quizzes` | List quizzes |
| POST | `/api/v1/courses/{id}/quizzes/{qid}/submit` | Submit quiz attempt |
| GET | `/api/v1/progress/courses/{id}` | Get course progress |
| POST | `/api/v1/progress/courses/{id}/lessons/{lid}` | Mark lesson complete |
| GET | `/api/v1/users` | List all users (admin only) |
| DELETE | `/api/v1/users/{id}` | Delete user (admin only) |

---

## 🛡️ Authentication & Roles

- **JWT Bearer tokens** stored in `localStorage`
- Token auto-attached to all API requests via Axios interceptor
- 401 responses auto-redirect to login
- Route protection via React Router + role checks
- Backend dependency injection for auth + role enforcement

| Role | Access |
|------|--------|
| `student` | Browse/enroll courses, watch lessons, take quizzes, track progress |
| `instructor` | CRUD own courses, lessons, quizzes; view enrolled students |
| `admin` | View/delete all users and courses |

---

## 🧱 Tech Stack

| Layer | Tech |
|-------|------|
| Frontend | React 18, Vite, React Router v6, Axios |
| Backend | FastAPI, SQLAlchemy 2.0, Pydantic v2 |
| Auth | JWT (python-jose), bcrypt (passlib) |
| Database | MySQL 8.0 |
| Styling | Pure CSS with CSS custom properties (no framework) |

---

## 🔧 Production Notes

- Change `SECRET_KEY` to a cryptographically random 32+ char string
- Set `DEBUG=False` in production `.env`
- Use environment variables for all secrets (never commit `.env`)
- Add HTTPS in production (nginx + certbot recommended)
- Consider Redis for token blacklisting on logout
- Add rate limiting for auth endpoints
